/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include"Usuarios.h"
#include<stdio.h>
#include<stdlib.h>

void registrar_usuario(char*,){
    
}
void mostrar_datos(int num_usu ){
    printf("ID:%s\nNombre:%s\nLocalidad:%s\nTipo Perfil:%s\nUsuario:%s\nContraseña:%s\nEstado:%s\n"),usuarios.Id_usuario,usuarios.Localidad),usuarios.Perfil_usuario,usuarios.Nomb_usuario,usuarios.Login,usuarios.Estado;
    
}
